<?php
include 'connection.php'; // Include database connection

$id = $_GET['id']; // Get student ID from the URL

// Fetch student details for the given ID
$sql = "SELECT * FROM students WHERE std_id = '$id'";
$result = $conn->query($sql);
$student = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form inputs
    $name = $_POST['std_name'];
    $course = $_POST['std_courses'];

    // Update query
    $sql = "UPDATE students SET std_name = '$name', std_courses = '$course' WHERE std_id = '$id'";

    if ($conn->query($sql) === TRUE) {
        header('Location: index.php'); // Redirect to the student list after success
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <center>
    <h2>Edit Student</h2>
    <form method="post">
        <label for="std_name">Student Name:</label><br>
        <input type="text" id="std_name" name="std_name" value="<?php echo $student['std_name']; ?>" required><br><br>

        <label for="std_courses">Course:</label><br>
        <input type="text" id="std_courses" name="std_courses" value="<?php echo $student['std_courses']; ?>" required><br><br>

        <input class="btn btn-success" type="submit" value="Update Student">
    </form>
    <br>
    <button class="btn btn-primary"> <a class="bs" href="index.php">Back to Student List</a></button>
    </center>   
</div>    
</body>
</html>
