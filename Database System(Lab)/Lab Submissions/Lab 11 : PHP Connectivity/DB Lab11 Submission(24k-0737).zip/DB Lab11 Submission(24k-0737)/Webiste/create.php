<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $isbn = $_POST['isbn_no'];
    $title = $_POST['title'];
    $author = $_POST['author'];

    $sql = "INSERT INTO books (ISBN_NO, Title, Author) 
            VALUES ('$isbn', '$title', '$author')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert alert-success'>Book added successfully!</div>";
    } else {
        echo "Error: " . $conn->error;
    }
}

$result = $conn->query("SELECT * FROM books");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Books</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <center>
        <h2>Add New Book</h2>

        <form method="post">
            <label>ISBN No:</label><br>
            <input type="text" name="isbn_no" required><br><br>

            <label>Title:</label><br>
            <input type="text" name="title" required><br><br>

            <label>Author:</label><br>
            <input type="text" name="author" required><br><br>

            <input class="btn btn-success" type="submit" value="Add Book">
        </form>

        <br><br>

        <h3>Books List</h3>

        <table class="table table-bordered">
            <tr>
                <th>ISBN No</th>
                <th>Title</th>
                <th>Author</th>
            </tr>

            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['ISBN_NO']}</td>
                            <td>{$row['Title']}</td>
                            <td>{$row['Author']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No books found</td></tr>";
            }
            ?>
        </table>

    </center>
</div>
</body>
</html>